import pygame
import random

#Fruit Class
class Fruit(pygame.sprite.Sprite):
    
    #init function - color, (x,y) cords
    def __init__(self, color, x, y, screen):
        #Parent class (Sprite) constructor
        pygame.sprite.Sprite.__init__(self)

        #creates a square and colors it in
        self.size = 25
        self.image = pygame.Surface((self.size, self.size))
        self.image.fill(color)

        #creates dimensions of the image and sets (x,y) cords
        self.rect = self.image.get_rect()
        self.fruit = self.rect #sets fruit to replace rect
        self.fruit.x = x-37.5
        self.fruit.y = y-37.5
    
    #sets random x, y location
    def newLocation(self,xList,yList):
        newX = (random.randint(1,12) * 50)-25
        newY = (random.randint(2,12) * 50)-25
        print("X/Y List:",xList,yList)
        print("New Pos",newX+25,newY+25)
        duplicate = True
        while duplicate:
            for i in range(len(xList)):
                if newX+25 == xList[i] and newY+25 == yList[i]:
                    print("x/y same-----------------------")
                    print(newX+25,xList[i],i)
                    print(newY+25,yList[i],i)
                    print()
                    newX = (random.randint(1,12) * 50)-25
                    newY = (random.randint(2,12) * 50)-25
                    
                else:
                    duplicate = False

        self.fruit.center = (newX,newY)
        print("fruit location",self.fruit.centerx + 25, self.fruit.centery+25)
        
    #get fruit x
    def get_x(self):
        return self.fruit.centerx

    #get fruit y
    def get_y(self):
        return self.fruit.centery
