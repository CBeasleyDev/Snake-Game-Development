#imports
import pygame
import random
import Snakes
import Fruits

#Game class    
class Game:
    def __init__(self):
        pygame.init()        
        #screen size
        self.width = 600
        self.height = 650

        #game window
        self.screen = pygame.display.set_mode((self.width,self.height))
        pygame.display.set_caption("Snake Game")
        
        #score text
        self.text = pygame.font.Font(None,35).render("0",True,"black")
        self.scoreText = self.text.get_rect()
        self.scoreText.center = (550,25)

        #frame rate
        self.clock = pygame.time.Clock()

        #create sprite group for snakes
        self.snakes = pygame.sprite.Group()
        self.snake = Snakes.Snake("lightgreen",50,50, self.screen)
        self.snakes.add(self.snake)

        #snake body
        self.body = Snakes.Body("green",50,0,50,0)

        #create sprite group for fruits
        self.fruits = pygame.sprite.Group()
        self.fruit = Fruits.Fruit("red",350,400, self.screen)
        self.fruits.add(self.fruit)

        self.playGame = False

    #files
    def save_high_score(self, score):
        with open("highscore.txt", "w") as file:
            file.write(str(score))

    def load_high_score(self):
        try:
            with open("highscore.txt", "r") as file:
                return int(file.read())
        except FileNotFoundError:
            return 0


    def playingGame(self):        
        #update background
        self.screen.fill("DarkGreen")
        self.screen.blit(self.text,self.scoreText)
        self.setText()
        self.drawGrid()

        #speed of game
        pygame.time.delay(100)
        self.clock.tick(10)
        
        #update snake location
        self.snakes.update()
        
        #update snake body location
        self.body.set_xy(self.snake.get_x(),self.snake.get_y())
        
        #draws snake body
        for i in range(self.body.get_length()):
            i += 1 # skip first placement --> head
            pygame.draw.rect(self.screen,self.body.get_color(),pygame.Rect(self.body.get_x(i),self.body.get_y(i),self.body.get_size(),self.body.get_size()))

        #draw fruit group
        self.fruits.draw(self.screen)

        #draw snake head
        self.snakes.draw(self.screen)
        
        #check for fruit collision
        self.collision(self.snake.get_x(),self.snake.get_y(), self.fruit.get_x(),self.fruit.get_y(), "fruit")

        #check for snake collision
        self.collision(self.snake.get_x(),self.snake.get_y(), self.body.get_allX(),self.body.get_allY(), "snake")
        
        #check for wall collision
        self.collision(self.snake.get_x(),self.snake.get_y(), self.body.get_allX(),self.body.get_allY(), "wall")
        
    #check for collision
    def collision(self, x1, y1, x2, y2, option):
        isOver = False
        if option == "fruit": #fruit collision
            if x1+25 == x2 and y1+25 == y2:
                self.fruit.newLocation(self.body.get_allX(),self.body.get_allY())
                self.body.set_length(1)

        elif option == "snake": #snake collision
            for i in range(len(x2)):
                if i > 0:
                    if x1 == x2[i] and y1 == y2[i]:

                        isOver = True      

        elif option == "wall": #wall collision
            if y1 < 50: #top wall
                isOver = True
            
            elif y1 > 600: #bottom wall
                isOver = True

            elif x1 < 0: #left wall
                isOver = True
                
            elif x1 > 550: #right wall
                isOver = True

        #call gameOver
        if isOver == True:
            self.gameOver()

    def gameOver(self):
        self.playGame = False #ends game
        self.screen.fill("Black")
        print("You died")
                
    def drawGrid(self):
        for i in range(12): 
            pos = i * 50 
            pygame.draw.rect(self.screen,"black",pygame.Rect(pos,50,1,600)) #vertical grid

            pos = (i+1) * 50 
            pygame.draw.rect(self.screen,"black",pygame.Rect(0,pos,600,1)) #horizontal grid

    def setText(self):
        self.score = self.body.get_length()
        self.text = pygame.font.Font(None,35).render(str(self.score),True,"black")

    def display_text(self, text, size, color, x, y):
        font = pygame.font.SysFont(None, size)
        rendered_text = font.render(text, True, color)
        self.screen.blit(rendered_text, (x, y))
    
    def color_selector(self,mouse_x, mouse_y):
        self.screen.fill((255, 255, 255))

        self.display_text("Choose Snake Color:", 30, (0, 0, 0), 50, 50)

        #color option
        color_options = [
            ("Red", (255, 0, 0)),
            ("Green", (0, 255, 0)),
            ("Blue", (0, 0, 255)),
            ("Yellow", (255, 255, 0)),
            ("Purple", (128, 0, 128)),
        ]
        
        color = None
        button_width, button_height = 150, 30
        x, y = 125, 100

        

        #set snake color and start game
        for i, (_, col) in enumerate(color_options):
            if (x < mouse_x < x + button_width and y + i * (button_height + 10) < mouse_y < y + i * (button_height + 10) + button_height):
                color = col
       
        #draw color options
        for i, (color_name, col) in enumerate(color_options):
            pygame.draw.rect(self.screen, col, (x, y + i * (button_height + 10), button_width, button_height))
            pygame.draw.rect(self.screen, (0, 0, 0), (x, y + i * (button_height + 10), button_width, button_height), 2)
            self.display_text(color_name, 20, (0, 0, 0), x + 10, y + 5 + i * (button_height + 10))
        if color:
            self.snake.set_color(color)
            self.body.set_color(color)
            return True
        
    def gameRunning(self):
        #game loop
        run = True
        while run:
            
            #checks for actions
            for event in pygame.event.get():
                #get keyboard input
                key = pygame.key.get_pressed()
                if event.type == pygame.KEYDOWN:
                    key = pygame.key.name(event.key)
                
                #checks for pressed key
                if key == "b": # b starts game
                   # self.playGame = True
                   pass

                if key == "n": #pause game
                    self.playGame = False
                
                elif key == "w": # w moves up
                    self.snake.move("Up")
                
                elif key == "s": # s moves down
                    self.snake.move("Down")
                
                elif key == "a": # a moves left
                    self.snake.move("Left")
                
                elif key == "d": # d moves right
                    self.snake.move("Right")
                    
                #close pygame window/exit game (p)
                elif key == "p":
                    run = False
                    pygame.quit()
                    
                elif key == "l": # l prints tail length
                    pass
                    #print(self.body.get_length())
                    
                elif key == "t": # t adds tail length by 1
                    pass
                    #self.body.set_length(1)
                    #self.fruit.newLocation(self.body.get_allX(),self.body.get_allY())
                    
                elif key == "r": # r new fruit location
                    pass
                    #self.fruit.newLocation(self.body.get_allX(),self.body.get_allY())

                #mous press
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_x, mouse_y = pygame.mouse.get_pos()
                    start = self.color_selector(mouse_x, mouse_y)
                    if start == True:
                        self.playGame = True
                
                #quit program    
                if event.type == pygame.QUIT:
                    run = False

            #check if game is being run
            if self.playGame == True:
                self.playingGame()
                
            #updates screen
            pygame.display.flip()

if __name__ == "__main__":
    game = Game()
    game.gameRunning()
