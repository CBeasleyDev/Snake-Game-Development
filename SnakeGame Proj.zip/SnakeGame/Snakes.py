import pygame
#Snake Head Class
class Snake(pygame.sprite.Sprite):
    
    #init function - color, (x,y) cords, screen
    def __init__(self, color, x, y, screen):
        #Parent class (Sprite) constructor
        pygame.sprite.Sprite.__init__(self)

        #creates a square and colors it in
        self.size = 50
        self.image = pygame.Surface((self.size, self.size))
        self.image.fill(color)

        #creates dimensions of the image
        self.rect = self.image.get_rect()
        self.snake = self.rect #sets snake to replace rect
        
        #x,y cords
        self.snake.x = x
        self.snake.y = y

        #direction the snake faces
        self.direction = "Down"

        self.color = color

    #getter methods
    def get_x(self):
        return self.snake.x

    def get_y(self):
        return self.snake.y

    def set_color(self,color):
        self.color = color
        
        

    #movement
    def update(self):
        
        #direction the snake is facing    
        if self.direction == "Up":
            self.snake.y -= self.size #5
        elif self.direction == "Down":
            self.snake.y += self.size #5
        elif self.direction == "Left":
            self.snake.x -= self.size #5
        elif self.direction == "Right":
            self.snake.x += self.size #5
        
    #snake movement
    def move(self,direction):
        if self.direction != "Down" and direction == "Up":
            self.direction = "Up"
        elif self.direction != "Up"  and direction == "Down":
            self.direction = "Down"
        elif self.direction != "Right" and direction == "Left":
            self.direction = "Left"
        elif self.direction != "Left" and direction == "Right":
            self.direction = "Right"

#Body Class for snake
class Body:
    def __init__(self,color,x,y,size,length):
        self.__color = color
        self.__x = [x]
        self.__y = [y]
        self.__size = size
        self.__length = length
        
    #getter methods
    def get_color(self):
        return self.__color
    
    def get_x(self,pos):
        return self.__x[pos]

    def get_y(self,pos):
        return self.__y[pos]

    def get_allX(self):
        return self.__x

    def get_allY(self):
        return self.__y

    def get_size(self):
        return self.__size

    def get_direction(self):
        return self.__direction

    def get_length(self):
        return self.__length
    

    #setter methods
    def set_color(self,color):
        self.__color = color
        print(self.__color)
        
    def set_xy(self, newX,newY):
        #new x
        self.__x.insert(0,newX)
        while len(self.__x) > self.__length + 1:
            self.__x.pop()

        #new y
        self.__y.insert(0,newY)
        while len(self.__y) > self.__length + 1:
            self.__y.pop()

    def set_length(self, newLen):
        self.__length += newLen
